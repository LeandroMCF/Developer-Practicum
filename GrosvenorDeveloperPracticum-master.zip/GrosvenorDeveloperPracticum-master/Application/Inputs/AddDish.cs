﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Inputs
{
    public class AddDish
    {
        public string time { get; set; }
        public string dishName { get; set; }
        public int count { get; set; }
    }
}
